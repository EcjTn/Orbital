let username = null;
let socket = null;
let isTyping = false; 

// Theme switching
document.querySelectorAll('.theme-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const theme = btn.getAttribute('data-theme');
    document.body.className = `theme-${theme}`;
  });
});

// Prompt for username on load
window.onload = () => {
  username = prompt('Please enter your username:');
  if (username && username.trim()) {
    username = username.trim();
    document.getElementById('usernameDisplay').textContent = `User: ${username}`;
    console.log(`Connected as ${username}`);
    connectSocket();
  } else {
    showError('Username is required!');
    setTimeout(() => {
      window.location.reload();
    }, 2000);
  }
};

function connectSocket() {
  socket = io('http://127.0.0.1:8000/chat', {
    auth: { username },
    reconnection: true,
    reconnectionAttempts: 5,
    reconnectionDelay: 1000
  });

  socket.on('connect', () => {
    console.log('Connected to Socket.IO server');
    socket.emit('joinRoom', "Public");

    // Normal messages
    socket.on('message', (data) => {
      const messageElement = document.createElement('div');
      messageElement.classList.add('message', data.username === username ? 'sent' : 'received');
      messageElement.innerHTML = `
        <span>${data.username}</span>
        <p>${data.message}</p>
      `;
      document.getElementById('chatMessages').appendChild(messageElement);
      document.getElementById('chatMessages').scrollTop = document.getElementById('chatMessages').scrollHeight;

      // clear typing indicator if message comes in
      //document.getElementById("typingIndicator").textContent = "";
    });

    // Announcements
    socket.on('joinAnnouncement', (data) => {
      showAnnouncement(data, "limegreen");
    });

    socket.on('leftAnnouncement', (data) => {
      showAnnouncement(data, "red");
    });

    // Typing indicator
    socket.on("showTyping", (typingUsers) => {
      if (!Array.isArray(typingUsers)) return;

      // filter self out
      const others = typingUsers.filter(user => user !== username);

      if (others.length === 0) {
        document.getElementById("typingIndicator").textContent = "";
      } else if (others.length === 1) {
        document.getElementById("typingIndicator").textContent = `${others[0]} is typing...`;
      } else if (others.length === 2) {
        document.getElementById("typingIndicator").textContent = `${others[0]}, ${others[1]} are typing...`;
      } else {
        document.getElementById("typingIndicator").textContent = "Several people are typing...";
      }
    });
  });

  socket.on('connect_error', (error) => {
    console.error('Socket.IO error:', error);
    showError(`Connection error: ${error.message}`);
  });

  socket.on('disconnect_error', (error) => {
    console.error('Socket.IO error:', error);
    showError(`Disconnection error: ${error.message}`);
  });
}

// Handle typing detection
function handleTyping() {
  // Send typing event with room name only
  isTyping = true
  socket.emit("typedIn", "Public");
}

// Show announcements in chat
function showAnnouncement(text, color) {
  const messageElement = document.createElement('div');
  messageElement.classList.add('message', 'announcement');
  messageElement.innerHTML = `<p>${text}</p>`;
  messageElement.style.color = color;
  document.getElementById('chatMessages').appendChild(messageElement);
  document.getElementById('chatMessages').scrollTop = document.getElementById('chatMessages').scrollHeight;
}

// Error modal
function showError(message) {
  document.getElementById('errorMessage').textContent = message;
  document.getElementById('errorModal').classList.add('active');
}

function closeErrorModal() {
  document.getElementById('errorModal').classList.remove('active');
}

// Send a message
function sendMessage() {
  const messageInput = document.getElementById('messageInput');
  const message = messageInput.value.trim();
  if (message && username) {
    socket.emit('message', { room: "Public", message });
    messageInput.value = '';
    isTyping = false;
  } else if (!username) {
    showError('Please enter a username first!');
  } else if (!socket.connected) {
    showError('Not connected to the server. Please try again later.');
  }
}

// Listen for typing events on browser
document.getElementById('messageInput').addEventListener('input', () => {
  if(!isTyping){
    handleTyping()
  }
});

// Allow Enter to send
document.getElementById('messageInput').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    sendMessage();
  }
});
